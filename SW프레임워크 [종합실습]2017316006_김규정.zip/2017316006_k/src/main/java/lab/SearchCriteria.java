package lab;

public class SearchCriteria {
	public String searchName; 
	public String getSearchName() {   
		return searchName;  
	}  
	public void setSearchName(String searchName) {   
		this.searchName = searchName;  
	} 
} 