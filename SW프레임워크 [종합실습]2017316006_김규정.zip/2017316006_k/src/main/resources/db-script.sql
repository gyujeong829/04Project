drop table customer;

CREATE TABLE customer (id VARCHAR(10),name VARCHAR(10),addr VARCHAR(255),tel varchar(30), gender varchar(10), PRIMARY KEY (id));